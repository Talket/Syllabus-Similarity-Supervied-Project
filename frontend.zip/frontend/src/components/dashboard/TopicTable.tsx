import React, { useState, useMemo } from 'react';
import { TopicItem } from '../../types/api';

interface TopicTableProps {
  topics: TopicItem[];
  effectiveThreshold?: number; // to filter by strictness threshold
}

export const TopicTable: React.FC<TopicTableProps> = ({
  topics,
  effectiveThreshold = 0.75,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'new' | 'covered'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Filter topics based on active tab, search query, and effective strictness threshold
  const filteredTopics = useMemo(() => {
    return topics.filter((t) => {
      // Re-evaluate covered status according to effective threshold if score is available
      const isActuallyCovered = t.covered && t.score >= effectiveThreshold;

      if (filterMode === 'new' && isActuallyCovered) return false;
      if (filterMode === 'covered' && !isActuallyCovered) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTopic = t.topic.toLowerCase().includes(q);
        const matchCounterpart = (t.match || '').toLowerCase().includes(q);
        if (!matchTopic && !matchCounterpart) return false;
      }

      return true;
    });
  }, [topics, filterMode, searchQuery, effectiveThreshold]);

  const counts = useMemo(() => {
    const coveredCount = topics.filter((t) => t.covered && t.score >= effectiveThreshold).length;
    return {
      all: topics.length,
      covered: coveredCount,
      new: topics.length - coveredCount,
    };
  }, [topics, effectiveThreshold]);

  return (
    <section className="dashboard-section" aria-label="Filterable Topic Inventory">
      <div className="section-header-row">
        <div>
          <div className="section-tag">
            <span className="accent">(Granularity) 6.4</span> Granular Topic Catalog
          </div>
          <h3 className="dashboard-subheading">Fine-Grained Concept Overlaps & Gaps</h3>
        </div>

        {/* Filter Tabs & Search Bar */}
        <div className="topic-controls-row">
          <div className="topic-filter-tabs num">
            <button
              type="button"
              className={`topic-tab-btn ${filterMode === 'all' ? 'is-active' : ''}`}
              onClick={() => setFilterMode('all')}
            >
              All Topics ({counts.all})
            </button>
            <button
              type="button"
              className={`topic-tab-btn tab-coral ${filterMode === 'new' ? 'is-active' : ''}`}
              onClick={() => setFilterMode('new')}
            >
              Novel ({counts.new})
            </button>
            <button
              type="button"
              className={`topic-tab-btn tab-yellow ${filterMode === 'covered' ? 'is-active' : ''}`}
              onClick={() => setFilterMode('covered')}
            >
              Covered ({counts.covered})
            </button>
          </div>

          <div className="topic-search-wrap">
            <input
              type="text"
              placeholder="Filter topics..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="topic-search-input num"
              aria-label="Filter topics list"
            />
            {searchQuery && (
              <button
                type="button"
                className="search-clear-btn"
                onClick={() => setSearchQuery('')}
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="topic-table-container">
        <table className="topic-data-table">
          <thead>
            <tr className="num">
              <th style={{ width: '8%' }}>UNIT</th>
              <th style={{ width: '38%' }}>TOPIC PHRASE</th>
              <th style={{ width: '14%' }}>STATUS</th>
              <th style={{ width: '12%' }}>SIMILARITY</th>
              <th style={{ width: '28%' }}>INT255 COUNTERPART MATCH</th>
            </tr>
          </thead>
          <tbody>
            {filteredTopics.length === 0 ? (
              <tr>
                <td colSpan={5} className="table-empty-cell num">
                  No topics matching the current filter criteria
                </td>
              </tr>
            ) : (
              filteredTopics.map((t, idx) => {
                const isCovered = t.covered && t.score >= effectiveThreshold;
                return (
                  <tr key={`${t.unit}-${t.topic}-${idx}`} className="topic-table-row">
                    <td className="topic-cell-unit num">
                      <span>U{t.unit}</span>
                    </td>

                    <td className="topic-cell-phrase">
                      <span className="marker-highlight hover:active">
                        {t.topic}
                      </span>
                    </td>

                    <td className="topic-cell-status">
                      {isCovered ? (
                        <span className="unit-status-chip status-covered">COVERED</span>
                      ) : (
                        <span className="unit-status-chip status-novel">NOVEL</span>
                      )}
                    </td>

                    <td className="topic-cell-score num">
                      {t.score > 0 ? (
                        <span className={isCovered ? 'text-yellow' : 'text-dim'}>
                          {t.score.toFixed(3)}
                        </span>
                      ) : (
                        <span className="text-dim">—</span>
                      )}
                    </td>

                    <td className="topic-cell-match">
                      {t.match ? (
                        <div className="topic-match-info">
                          <span className="topic-match-name" title={t.match}>
                            {t.match}
                          </span>
                          <span className="topic-match-course num">
                            {t.course_title || 'INT255'} · U{t.match_unit || 4}
                          </span>
                        </div>
                      ) : (
                        <span className="text-dim num">Unique proposal addition</span>
                      )}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
};
