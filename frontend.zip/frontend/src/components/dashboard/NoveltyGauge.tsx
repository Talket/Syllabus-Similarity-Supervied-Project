import React from 'react';
import { Report } from '../../types/api';

interface NoveltyGaugeProps {
  report: Report;
  onDownloadJson?: () => void;
}

export const NoveltyGauge: React.FC<NoveltyGaugeProps> = ({ report, onDownloadJson }) => {
  const noveltyPct = Math.round(report.novelty * 100);
  
  // Radial Arc Gauge calculation
  // Radius = 85, Circumference = 2 * PI * 85 ~= 534
  // Arc angle = 260 degrees -> length ~= 385
  const radius = 80;
  const strokeWidth = 10;
  const arcLength = 2 * Math.PI * radius * (260 / 360);
  const strokeDashoffset = arcLength * (1 - report.novelty);

  return (
    <section className="dashboard-section" aria-label="Novelty and Overview Metrics">
      <div className="section-header-row">
        <div>
          <div className="section-tag">
            <span className="accent">(Synthesis) 6.0</span> Proposal Novelty Analysis
          </div>
          <h2 className="dashboard-heading">Curriculum Expansion Index</h2>
        </div>

        {onDownloadJson && (
          <button
            type="button"
            className="json-download-btn num cursor-pointer"
            onClick={onDownloadJson}
            title="Download full machine-readable comparison report JSON"
          >
            <span>Download Report (.json)</span>
            <span className="btn-glyph">↓</span>
          </button>
        )}
      </div>

      <div className="metrics-banner-grid">
        {/* Radial Arc Gauge Card */}
        <div className="gauge-card">
          <div className="gauge-svg-wrap">
            <svg className="gauge-svg" viewBox="0 0 200 200" aria-hidden="true">
              {/* Background Arc */}
              <circle
                cx="100"
                cy="105"
                r={radius}
                fill="none"
                stroke="rgba(242, 241, 237, 0.08)"
                strokeWidth={strokeWidth}
                strokeDasharray={`${arcLength} 600`}
                strokeLinecap="round"
                transform="rotate(140 100 105)"
              />
              {/* Animated Value Arc */}
              <circle
                cx="100"
                cy="105"
                r={radius}
                fill="none"
                stroke="#ff6b6b"
                strokeWidth={strokeWidth}
                strokeDasharray={`${arcLength} 600`}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                transform="rotate(140 100 105)"
                className="gauge-val-arc"
              />
            </svg>

            <div className="gauge-center-text">
              <span className="gauge-pct-val num" data-num={noveltyPct}>{noveltyPct}%</span>
              <span className="gauge-pct-label num">NOVELTY SCORE</span>
            </div>
          </div>

          <div className="gauge-card-footer num">
            <span className="text-coral">HIGH NOVELTY</span>
            <span className="gauge-card-sep">·</span>
            <span>+10pt Calibrated</span>
          </div>
        </div>

        {/* Headline Stat Cards */}
        <div className="headline-stats-grid">
          {/* Card 1: New Topics */}
          <div className="metric-stat-card">
            <div className="metric-stat-top num">
              <span className="metric-stat-idx">01</span>
              <span className="metric-badge badge-coral">NET NOVEL</span>
            </div>
            <div className="metric-stat-body">
              <span className="metric-stat-number num text-coral">{report.topics.new}</span>
              <span className="metric-stat-sub num">of {report.topics.total} proposal topics</span>
            </div>
            <p className="metric-stat-caption">
              Content topics with zero counterparts in the comparison syllabus.
            </p>
          </div>

          {/* Card 2: Covered Topics */}
          <div className="metric-stat-card">
            <div className="metric-stat-top num">
              <span className="metric-stat-idx">02</span>
              <span className="metric-badge badge-yellow">OVERLAP</span>
            </div>
            <div className="metric-stat-body">
              <span className="metric-stat-number num text-yellow">{report.topics.covered}</span>
              <span className="metric-stat-sub num">matched topics</span>
            </div>
            <p className="metric-stat-caption">
              Concepts that share high semantic cosine affinity (≥ 0.75) with existing units.
            </p>
          </div>

          {/* Card 3: Units Analyzed */}
          <div className="metric-stat-card">
            <div className="metric-stat-top num">
              <span className="metric-stat-idx">03</span>
              <span className="metric-badge badge-cyan">STRUCTURE</span>
            </div>
            <div className="metric-stat-body">
              <span className="metric-stat-number num text-cyan">{report.n_units}</span>
              <span className="metric-stat-sub num">curricular units</span>
            </div>
            <p className="metric-stat-caption">
              Partitioned instructional modules mapped into vector meaning space.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
