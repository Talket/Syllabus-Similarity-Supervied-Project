import React, { useState } from 'react';

interface StrictnessSliderProps {
  currentStrictness: number; // e.g. 0.75
  baselineStrictness?: number; // threshold used for current API dataset
  onChangeLocal: (newStrictness: number) => void;
  onReRequestApi: (newStrictness: number) => Promise<void>;
  isLoading?: boolean;
}

export const StrictnessSlider: React.FC<StrictnessSliderProps> = ({
  currentStrictness,
  baselineStrictness = 0.75,
  onChangeLocal,
  onReRequestApi,
  isLoading = false,
}) => {
  const [val, setVal] = useState<number>(currentStrictness);
  const [isPendingApi, setIsPendingApi] = useState<boolean>(false);

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVal = parseFloat(e.target.value);
    setVal(newVal);

    // If raised above baseline, filter locally immediately
    if (newVal >= baselineStrictness) {
      onChangeLocal(newVal);
    }
  };

  const handleRelease = async () => {
    // If lowered below baseline, must re-request backend API with new t_phrase
    if (val < baselineStrictness) {
      try {
        setIsPendingApi(true);
        await onReRequestApi(val);
      } catch (err) {
        console.error('Failed to recalibrate with new strictness', err);
      } finally {
        setIsPendingApi(false);
      }
    } else {
      onChangeLocal(val);
    }
  };

  const handleReset = async () => {
    setVal(0.75);
    onChangeLocal(0.75);
    if (baselineStrictness !== 0.75) {
      try {
        setIsPendingApi(true);
        await onReRequestApi(0.75);
      } finally {
        setIsPendingApi(false);
      }
    }
  };

  const isLowered = val < baselineStrictness;

  return (
    <div className="strictness-panel-card" aria-label="Topic Matching Strictness Calibration">
      <div className="strictness-header">
        <div className="strictness-header-left">
          <div className="section-tag">
            <span className="accent">(Calibration) 6.5</span> Semantic Matching Sensitivity
          </div>
          <h4 className="strictness-title">Topic Matching Strictness (t_phrase)</h4>
          <p className="strictness-desc">
            Cosine similarity threshold required before two topic phrases are marked as matched.
            Raising filters strictly; lowering triggers embedding re-evaluation.
          </p>
        </div>

        <div className="strictness-val-badge num">
          <span className="val-number">{val.toFixed(2)}</span>
          <span className="val-state">
            {isLowered ? (
              <span className="badge-warning">EXPAND COVERAGE</span>
            ) : (
              <span className="badge-ok">LOCAL STRICTNESS</span>
            )}
          </span>
        </div>
      </div>

      <div className="slider-control-container">
        <div className="slider-track-wrap">
          <input
            type="range"
            min="0.40"
            max="0.95"
            step="0.01"
            value={val}
            onChange={handleSliderChange}
            onMouseUp={handleRelease}
            onTouchEnd={handleRelease}
            onKeyUp={handleRelease}
            className="strictness-range-input cursor-pointer"
            aria-label="Topic matching threshold"
            disabled={isLoading || isPendingApi}
          />
        </div>

        {/* Calibration Ticks */}
        <div className="slider-ticks-row num">
          <div className="slider-tick">
            <span className="tick-line" />
            <span className="tick-val">0.40</span>
            <span className="tick-label">Loose</span>
          </div>
          <div className="slider-tick tick-anchor">
            <span className="tick-line" />
            <span className="tick-val">0.51</span>
            <span className="tick-label">t_high</span>
          </div>
          <div className="slider-tick tick-anchor tick-default">
            <span className="tick-line" />
            <span className="tick-val">0.75</span>
            <span className="tick-label">Default (t_phrase)</span>
          </div>
          <div className="slider-tick">
            <span className="tick-line" />
            <span className="tick-val">0.95</span>
            <span className="tick-label">Exact</span>
          </div>
        </div>
      </div>

      <div className="strictness-footer">
        <div className="strictness-status-info num">
          {(isLoading || isPendingApi) ? (
            <div className="slider-loading-state">
              <span className="spinner-dot" />
              <span className="text-yellow">Re-evaluating topic embeddings on model with t_phrase={val.toFixed(2)}...</span>
            </div>
          ) : isLowered ? (
            <span className="text-coral">
              Release slider to query API for looser candidate overlaps below baseline {baselineStrictness.toFixed(2)}.
            </span>
          ) : (
            <span className="text-dim">
              Local active filtering applied instantly in memory.
            </span>
          )}
        </div>

        {val !== 0.75 && (
          <button
            type="button"
            className="strictness-reset-btn num cursor-pointer"
            onClick={handleReset}
            disabled={isLoading || isPendingApi}
          >
            Reset to 0.75
          </button>
        )}
      </div>
    </div>
  );
};
