import React from 'react';
import { TopicItem, VizLink } from '../../types/api';

interface LiveIndexListProps {
  topics: TopicItem[];
  activeTopicIndex: number | null; // currently highlighted in match sequence
  matchedLinks?: VizLink[];
  progress?: number;
  onSelectTopic?: (topic: TopicItem) => void;
  visible?: boolean;
}

export const LiveIndexList: React.FC<LiveIndexListProps> = ({
  topics,
  activeTopicIndex,
  onSelectTopic,
  visible = true,
}) => {
  if (!visible) return null;

  return (
    <aside className="live-index-aside" aria-label="Proposal Topic Stream">
      <div className="live-index-header">
        <span className="live-index-title num">(Topic Index) 1.2</span>
        <span className="live-index-count num">{topics.length} topics</span>
      </div>

      <div className="live-index-scroll">
        <ol className="live-index-list">
          {topics.map((t, idx) => {
            const isActive = activeTopicIndex === idx;
            const isCovered = t.covered;

            return (
              <li
                key={`${t.unit}-${t.topic}-${idx}`}
                className={`live-index-item ${isActive ? 'is-active' : ''} ${isCovered ? 'is-covered' : 'is-novel'}`}
                onClick={() => onSelectTopic?.(t)}
              >
                <div className="live-index-item-meta num">
                  <span className="live-index-unit">U{t.unit}</span>
                  {isCovered && t.score > 0 && (
                    <span className="live-index-score">{t.score.toFixed(3)}</span>
                  )}
                  {!isCovered && (
                    <span className="live-index-novel-pill">NOVEL</span>
                  )}
                </div>

                <div className="live-index-phrase-wrap">
                  <span
                    className={`marker-highlight ${isActive ? 'active' : ''}`}
                    title={t.topic}
                  >
                    {t.topic}
                  </span>
                </div>

                {isActive && t.match && (
                  <div className="live-index-match-preview">
                    <span className="live-index-match-label">Matched with INT255:</span>
                    <span className="live-index-match-text">“{t.match}”</span>
                  </div>
                )}
              </li>
            );
          })}
        </ol>
      </div>
    </aside>
  );
};

