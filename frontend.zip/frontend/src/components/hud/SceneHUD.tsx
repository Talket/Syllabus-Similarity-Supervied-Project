import React from 'react';
import { Report } from '../../types/api';

interface SceneHUDProps {
  currentScene: number; // 0..5
  report: Report;
  onSkipAnimation?: () => void;
  onOpenUpload?: () => void;
  showSkip?: boolean;
}

export const SceneHUD: React.FC<SceneHUDProps> = ({
  currentScene,
  report,
  onSkipAnimation,
  onOpenUpload,
  showSkip = true,
}) => {
  const sceneNames = [
    { label: '(Overview) 0.0', sub: 'Course Intelligence' },
    { label: '(Read) 1.0', sub: 'Document Intake' },
    { label: '(Split) 2.0', sub: `2.1 Units ${report.n_units} / 2.2 Topics ${report.topics.total}` },
    { label: '(Embed) 3.0', sub: `3.1 PCA Projection (${report.topics.total} pts)` },
    { label: '(Match) 4.0', sub: `4.1 Cosine Pairs (Matched ${report.topics.covered})` },
    { label: '(Verdict) 5.0', sub: `5.1 Novelty ${Math.round(report.novelty * 100)}% (${report.topics.new} new)` },
  ];

  const activeMeta = sceneNames[Math.min(Math.max(0, currentScene), 5)];
  const counterText = currentScene === 0 ? '00 / 05' : `0${currentScene} / 05`;

  return (
    <div className="hud-root" aria-live="polite">
      {/* Top Left: Title and Scene Parenthetical */}
      <div className="hud-top-left">
        <div className="hud-brand">
          <span className="hud-logo-icon">▲</span>
          <span className="hud-title">Syllabus Lens</span>
          <span className="hud-version num">v1.0</span>
        </div>
        <div className="hud-scene-tag">
          <span className="section-tag">
            <span className="accent">{activeMeta.label}</span>
          </span>
          <span className="hud-sub-index num">{activeMeta.sub}</span>
        </div>
      </div>

      {/* Top Right: Counter & Actions */}
      <div className="hud-top-right">
        {onOpenUpload && (
          <button
            type="button"
            className="hud-upload-btn num cursor-pointer"
            onClick={onOpenUpload}
            aria-label="Upload two course syllabi"
          >
            <span>Upload Syllabi</span>
            <span className="hud-btn-arrow">↑</span>
          </button>
        )}

        {showSkip && onSkipAnimation && (
          <button
            type="button"
            className="hud-skip-btn num cursor-pointer"
            onClick={onSkipAnimation}
            aria-label="Skip animation to dashboard"
          >
            <span>Skip to Results</span>
            <span className="hud-btn-arrow">↓</span>
          </button>
        )}
        <div className="hud-counter-pill num">
          <span className="hud-counter-val">{counterText}</span>
        </div>
      </div>

      {/* Bottom Progress Bar */}
      <div className="hud-bottom-bar" aria-hidden="true">
        <div
          className="hud-progress-fill"
          style={{ width: `${(Math.max(0, currentScene) / 5) * 100}%` }}
        />
      </div>
    </div>
  );
};

