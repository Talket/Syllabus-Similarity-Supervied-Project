import React from 'react';
import { ParsedDoc } from '../../types/api';

interface ReadSceneProps {
  progress: number; // 0..1
  parsedA: ParsedDoc;
  parsedB: ParsedDoc;
}

export const ReadScene: React.FC<ReadSceneProps> = ({ progress, parsedA, parsedB }) => {
  // Phase 1: 0..0.45: Scan beam moves over single sheet
  // Phase 2: 0.45..0.85: Sheet morphs and splits into two sheets side by side
  // Phase 3: 0.85..1.0: Real unit lines shimmer in
  const scanProgress = Math.min(1, Math.max(0, progress / 0.45));
  const splitProgress = Math.min(1, Math.max(0, (progress - 0.4) / 0.45));
  const shimmerProgress = Math.min(1, Math.max(0, (progress - 0.75) / 0.25));

  // Interpolate sheet positions
  // Left sheet starts at center (x: 0), moves left to -55%
  // Right sheet starts invisible at center, moves right to +55% with opacity fading in
  const leftTranslateX = -splitProgress * 55;
  const rightTranslateX = splitProgress * 55;
  const rightOpacity = Math.min(1, splitProgress * 1.5);

  return (
    <div className="scene-viewport scene-read" aria-label="Scene 1: Document Intake and Reading">
      <div className="scene-bg-label num">(Read) 1.0</div>

      {/* Center Stage for Sheets */}
      <div className="read-stage">
        {/* Document A Sheet (Proposal) */}
        <div
          className="paper-sheet paper-sheet-a"
          style={{
            transform: `translateX(${leftTranslateX}%) scale(${1 - splitProgress * 0.05})`,
          }}
        >
          {/* Scan Beam */}
          {scanProgress > 0 && scanProgress < 1 && (
            <div
              className="scan-beam"
              style={{
                top: `${scanProgress * 100}%`,
              }}
              aria-hidden="true"
            />
          )}

          <div className="sheet-header">
            <span className="sheet-badge num">SYLLABUS A · PROPOSAL</span>
            <div className="sheet-code num">{parsedA.code || 'CSE275'}</div>
          </div>

          <h2 className="sheet-title">{parsedA.title}</h2>
          <div className="sheet-divider" />

          {/* Lines of Real Unit Text */}
          <div className="sheet-units-preview">
            {parsedA.units.slice(0, 5).map((u) => (
              <div
                key={u.order}
                className="sheet-unit-item"
                style={{
                  opacity: 0.4 + shimmerProgress * 0.6,
                }}
              >
                <div className="sheet-unit-order num">Unit 0{u.order}</div>
                <div className="sheet-unit-heading">{u.title}</div>
                <p className="sheet-unit-excerpt">{u.text.slice(0, 110)}...</p>
              </div>
            ))}
          </div>

          <div className="sheet-footer num">
            <span>FORMAT: {parsedA.format?.toUpperCase() || 'UNIT'}</span>
            <span>CREDITS: {parsedA.credits || 3}</span>
          </div>
        </div>

        {/* Document B Sheet (Comparison / Existing) */}
        <div
          className="paper-sheet paper-sheet-b"
          style={{
            transform: `translateX(${rightTranslateX}%) scale(${1 - splitProgress * 0.05})`,
            opacity: rightOpacity,
            pointerEvents: rightOpacity > 0.5 ? 'auto' : 'none',
          }}
        >
          <div className="sheet-header">
            <span className="sheet-badge sheet-badge-b num">SYLLABUS B · LIBRARY MATCH</span>
            <div className="sheet-code num">{parsedB.code || 'INT255'}</div>
          </div>

          <h2 className="sheet-title">{parsedB.title}</h2>
          <div className="sheet-divider" />

          {/* Lines of Real Unit Text */}
          <div className="sheet-units-preview">
            {parsedB.units.slice(0, 5).map((u) => (
              <div
                key={u.order}
                className="sheet-unit-item"
                style={{
                  opacity: 0.4 + shimmerProgress * 0.6,
                }}
              >
                <div className="sheet-unit-order num">Unit 0{u.order}</div>
                <div className="sheet-unit-heading">{u.title}</div>
                <p className="sheet-unit-excerpt">{u.text.slice(0, 110)}...</p>
              </div>
            ))}
          </div>

          <div className="sheet-footer num">
            <span>FORMAT: {parsedB.format?.toUpperCase() || 'UNIT'}</span>
            <span>CREDITS: {parsedB.credits || 3}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
