import React from 'react';

interface HeroSceneProps {
  progress?: number;
  onExplore?: () => void;
  onOpenUpload?: () => void;
}

export const HeroScene: React.FC<HeroSceneProps> = ({ onExplore, onOpenUpload }) => {
  return (
    <section className="scene-hero" aria-label="Hero Introduction">
      {/* Drifting Paper Sheet in Background */}
      <div className="hero-sheet-container" aria-hidden="true">
        <div className="hero-drifting-sheet">
          <div className="sheet-watermark num">SYLLABUS LENS · NLP 2026</div>
          <div className="sheet-rule-line" style={{ width: '40%' }} />
          <div className="sheet-rule-line" style={{ width: '75%' }} />
          <div className="sheet-rule-line" style={{ width: '60%' }} />
          <div className="sheet-rule-line" style={{ width: '85%' }} />
          <div className="sheet-rule-line" style={{ width: '30%' }} />
          <div className="sheet-stamp num">FINE-TUNED DEEP LEARNING MODEL</div>
        </div>
      </div>

      {/* Main Foreground Content */}
      <div className="hero-content">
        <div className="hero-meta">
          <span className="section-tag">
            <span className="accent">(Curriculum Committee Intelligence)</span> 0.0
          </span>
          <span className="hero-date num">EST. 2026</span>
        </div>

        <h1 className="hero-headline">
          Find what is <br />
          <span className="hero-headline-em">actually new.</span>
        </h1>

        <p className="hero-subtext">
          A fine-tuned language model reads two course syllabi, projects topic phrases into
          semantic meaning-space, and isolates what the proposal truly adds that no existing
          curriculum covers.
        </p>

        <div className="hero-actions">
          <button
            type="button"
            className="hero-primary-btn num cursor-pointer"
            onClick={onExplore}
          >
            <span>Begin Visual Journey</span>
            <span className="btn-glyph">↓</span>
          </button>

          {onOpenUpload && (
            <button
              type="button"
              className="hero-secondary-btn num cursor-pointer"
              onClick={onOpenUpload}
            >
              <span>Upload Custom Syllabi</span>
              <span className="btn-glyph">↑</span>
            </button>
          )}
          
          <div className="hero-scroll-cue num">
            <span className="scroll-cue-dot" />
            <span>SCROLL TO SCRUB TIMELINE</span>
          </div>
        </div>
      </div>
    </section>
  );
};

