import React from 'react';
import { Report, TopicItem } from '../../types/api';

interface SplitSceneProps {
  progress: number; // 0..1
  report: Report;
}

export const SplitScene: React.FC<SplitSceneProps> = ({ progress, report }) => {
  // Phase 1: 0..0.5: Sheets break into Unit blocks
  // Phase 2: 0.5..1.0: Unit blocks shatter into Topic chips
  const unitBreakProgress = Math.min(1, Math.max(0, progress / 0.5));
  const topicShatterProgress = Math.min(1, Math.max(0, (progress - 0.45) / 0.55));

  // Count animations
  const visibleUnitsCount = Math.min(
    report.n_units,
    Math.max(1, Math.round(unitBreakProgress * report.n_units))
  );
  const visibleTopicsCount = Math.min(
    report.topics.total,
    Math.round(topicShatterProgress * report.topics.total)
  );

  return (
    <div className="scene-viewport scene-split" aria-label="Scene 2: Split into Units and Topic Chips">
      {/* Editorial Counters Header */}
      <div className="split-counters-header">
        <div className="section-tag">
          <span className="accent">(Split) 2.0</span> Unit & Topic Segmentation
        </div>
        <div className="split-indices num">
          <span className="split-sub-tag">
            2.1 Units <strong className="split-highlight-val">{visibleUnitsCount}</strong> / {report.n_units}
          </span>
          <span className="split-divider">/</span>
          <span className="split-sub-tag">
            2.2 Topics <strong className="split-highlight-val">{visibleTopicsCount}</strong> / {report.topics.total}
          </span>
        </div>
      </div>

      <div className="split-stage">
        {/* Unit Blocks Grid (Transforms and disperses) */}
        <div
          className="units-grid"
          style={{
            opacity: Math.max(0.15, 1 - topicShatterProgress * 0.7),
            transform: `scale(${1 - topicShatterProgress * 0.08})`,
          }}
        >
          {report.units.slice(0, 6).map((u, i) => {
            const isVisible = i < visibleUnitsCount;
            const staggerX = (i % 2 === 0 ? -1 : 1) * unitBreakProgress * (10 + i * 4);
            const staggerY = (Math.floor(i / 2) - 1) * unitBreakProgress * 15;

            return (
              <div
                key={u.order}
                className={`unit-block-card ${isVisible ? 'is-visible' : 'is-hidden'}`}
                style={{
                  transform: `translate(${staggerX}px, ${staggerY}px)`,
                  transition: 'opacity 0.4s ease',
                }}
              >
                <div className="unit-card-header">
                  <span className="unit-card-badge num">UNIT 0{u.order}</span>
                  <span className={`unit-status-chip status-${u.status.toLowerCase().replace(/\s+/g, '-')}`}>
                    {u.status}
                  </span>
                </div>
                <h4 className="unit-card-title">{u.title}</h4>
                <div className="unit-card-bar">
                  <div
                    className="unit-card-bar-fill"
                    style={{ width: `${Math.round((u.best_score || 0.4) * 100)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>

        {/* Shattered Topic Chips Cloud Overlay */}
        {topicShatterProgress > 0 && (
          <div
            className="topics-shatter-layer"
            style={{
              opacity: topicShatterProgress,
            }}
          >
            {report.topics.items.slice(0, 36).map((t: TopicItem, idx: number) => {
              // Deterministic organic wide scatter
              const angle = (idx / 36) * Math.PI * 2 + 0.3;
              const radius = 180 + ((idx * 67) % 380) * topicShatterProgress;
              const posX = Math.cos(angle) * radius * 1.35;
              const posY = Math.sin(angle) * radius * 0.75;
              const rot = ((idx * 37) % 30 - 15) * topicShatterProgress;

              return (
                <div
                  key={`${t.unit}-${t.topic}-${idx}`}
                  className={`topic-chip ${t.covered ? 'chip-covered' : 'chip-novel'}`}
                  style={{
                    transform: `translate(${posX}px, ${posY}px) rotate(${rot}deg) scale(${0.8 + topicShatterProgress * 0.2})`,
                    opacity: Math.min(1, topicShatterProgress * 1.3),
                  }}
                >
                  <span className="chip-unit-num num">U{t.unit}</span>
                  <span className="chip-text">{t.topic}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
