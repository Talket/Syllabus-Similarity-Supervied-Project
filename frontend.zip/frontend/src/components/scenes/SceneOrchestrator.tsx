import React, { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ComparePairResponse } from '../../types/api';
import { HeroScene } from './HeroScene';
import { ReadScene } from './ReadScene';
import { SplitScene } from './SplitScene';
import { EmbedScene } from './EmbedScene';
import { MatchScene } from './MatchScene';
import { VerdictScene } from './VerdictScene';
import { SceneHUD } from '../hud/SceneHUD';
import { LiveIndexList } from '../hud/LiveIndexList';

gsap.registerPlugin(ScrollTrigger);

interface SceneOrchestratorProps {
  data: ComparePairResponse;
  onFinishAnimation?: () => void;
  onOpenUpload?: () => void;
  mode?: 'scroll' | 'timeline' | 'presenter';
  isDataReady?: boolean;
  onExitPresenter?: () => void;
}

export const SceneOrchestrator: React.FC<SceneOrchestratorProps> = ({
  data,
  onFinishAnimation,
  onOpenUpload,
  mode = 'scroll',
  isDataReady = true,
  onExitPresenter,
}) => {
  const trackRef = useRef<HTMLDivElement>(null);
  const viewportRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<gsap.core.Timeline | null>(null);

  const [currentScene, setCurrentScene] = useState<number>(mode === 'timeline' ? 1 : 0);
  const [sceneProgress, setSceneProgress] = useState<number>(0);
  const [activeTopicIndex, setActiveTopicIndex] = useState<number | null>(null);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [overallProgress, setOverallProgress] = useState<number>(0);

  // 1. Scroll-Scrubbed Mode (Landing Page)
  useEffect(() => {
    // Check if direct scene query param is set (e.g. ?scene=2&p=0.5)
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const sceneParam = params.get('scene');
      if (sceneParam !== null) {
        const s = parseInt(sceneParam, 10);
        if (!isNaN(s) && s >= 0 && s <= 5) {
          setCurrentScene(s);
          const pParam = parseFloat(params.get('p') || '0.65');
          setSceneProgress(isNaN(pParam) ? 0.65 : Math.min(1, Math.max(0, pParam)));
          return;
        }
      }
    }

    if (mode !== 'scroll') return;

    const track = trackRef.current;
    const viewport = viewportRef.current;
    if (!track || !viewport) return;

    const ctx = gsap.context(() => {
      ScrollTrigger.create({
        trigger: track,
        pin: viewport,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.8,
        onUpdate: (self) => {
          const p = self.progress; // 0..1 across 1400vh

          let scene = 0;
          let subProgress = 0;

          if (p <= 0.08) {
            scene = 0;
            subProgress = p / 0.08;
          } else if (p <= 0.27) {
            scene = 1;
            subProgress = (p - 0.08) / 0.19;
          } else if (p <= 0.46) {
            scene = 2;
            subProgress = (p - 0.27) / 0.19;
          } else if (p <= 0.70) {
            scene = 3;
            subProgress = (p - 0.46) / 0.24;
          } else if (p <= 0.89) {
            scene = 4;
            subProgress = (p - 0.70) / 0.19;
          } else {
            scene = 5;
            subProgress = (p - 0.89) / 0.11;
          }

          setCurrentScene(scene);
          setSceneProgress(Math.min(1, Math.max(0, subProgress)));
        },
      });
    }, track);

    return () => ctx.revert();
  }, [mode]);

  // 2. Time-Driven Mode (Post-Upload Processing Timeline)
  useEffect(() => {
    if (mode !== 'timeline') return;

    const tl = gsap.timeline({
      defaults: { ease: 'power2.inOut' },
      onComplete: () => {
        onFinishAnimation?.();
      },
    });

    timelineRef.current = tl;

    // Stage 1: Scene 1 Read (0 -> 1 over 1.8s)
    tl.call(() => setCurrentScene(1))
      .to({}, {
        duration: 1.8,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })

      // Stage 2: Scene 2 Split (0 -> 1 over 1.8s)
      .call(() => setCurrentScene(2))
      .to({}, {
        duration: 1.8,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })

      // Stage 3: Scene 3 Embed (0 -> 1 over 2.2s)
      .call(() => setCurrentScene(3))
      .to({}, {
        duration: 2.2,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      });

    // If data is ready, continue immediately into Scene 4 and 5
    if (isDataReady) {
      tl.call(() => setCurrentScene(4))
        .to({}, {
          duration: 2.5,
          onUpdate: function () {
            setSceneProgress(this.progress());
          },
        })
        .call(() => setCurrentScene(5))
        .to({}, {
          duration: 2.2,
          onUpdate: function () {
            setSceneProgress(this.progress());
          },
        });
    }

    return () => {
      tl.kill();
      timelineRef.current = null;
    };
  }, [mode, isDataReady, onFinishAnimation]);

  // 3. Presenter Mode: ~60s Full Cinematic Auto-Play with Keyboard Scrubbing
  useEffect(() => {
    if (mode !== 'presenter') return;

    const tl = gsap.timeline({
      defaults: { ease: 'power2.inOut' },
      onUpdate: function () {
        setOverallProgress(this.progress());
      },
      onComplete: () => {
        handleSkipAnimation();
      },
    });

    timelineRef.current = tl;

    // Stage 0: Hero (6s)
    tl.call(() => setCurrentScene(0))
      .to({}, {
        duration: 6,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })
      // Stage 1: Read (10s)
      .call(() => setCurrentScene(1))
      .to({}, {
        duration: 10,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })
      // Stage 2: Split (10s)
      .call(() => setCurrentScene(2))
      .to({}, {
        duration: 10,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })
      // Stage 3: Embed (12s)
      .call(() => setCurrentScene(3))
      .to({}, {
        duration: 12,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })
      // Stage 4: Match (12s)
      .call(() => setCurrentScene(4))
      .to({}, {
        duration: 12,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      })
      // Stage 5: Verdict (10s)
      .call(() => setCurrentScene(5))
      .to({}, {
        duration: 10,
        onUpdate: function () {
          setSceneProgress(this.progress());
        },
      });

    const handleKeyDown = (e: KeyboardEvent) => {
      // Space to toggle pause/resume
      if (e.code === 'Space') {
        e.preventDefault();
        if (tl.paused()) {
          tl.resume();
          setIsPaused(false);
        } else {
          tl.pause();
          setIsPaused(true);
        }
      }
      // Right arrow: step forward ~5s
      else if (e.code === 'ArrowRight') {
        e.preventDefault();
        tl.time(Math.min(tl.duration(), tl.time() + 5));
      }
      // Left arrow: step backward ~5s
      else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        tl.time(Math.max(0, tl.time() - 5));
      }
      // F: toggle fullscreen
      else if (e.code === 'KeyF') {
        e.preventDefault();
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(() => {});
        } else {
          document.exitFullscreen().catch(() => {});
        }
      }
      // Escape: exit presenter mode
      else if (e.code === 'Escape') {
        e.preventDefault();
        if (document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
        tl.kill();
        onExitPresenter?.();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      tl.kill();
      timelineRef.current = null;
    };
  }, [mode, onExitPresenter]);

  const handleSkipAnimation = () => {
    if (timelineRef.current) {
      timelineRef.current.kill();
    }
    const dashboardEl = document.getElementById('results-dashboard');
    if (dashboardEl) {
      dashboardEl.scrollIntoView({ behavior: 'smooth' });
    }
    onFinishAnimation?.();
  };

  const handleScrollToNext = () => {
    window.scrollBy({ top: window.innerHeight * 1.5, behavior: 'smooth' });
  };

  return (
    <div className={`orchestrator-wrapper ${mode === 'timeline' || mode === 'presenter' ? 'is-timeline-mode' : ''} ${mode === 'presenter' ? 'is-presenter-mode' : ''}`}>
      {/* Presenter Mode Controls Bar */}
      {mode === 'presenter' && (
        <div
          role="region"
          aria-label="Presenter Controls"
          className="presenter-controls-bar num"
        >
          <div className="presenter-badge">
            <span className="presenter-pulse-dot" />
            <span>PRESENTER MODE (60s DEMO)</span>
          </div>

          <div className="presenter-progress-bar-wrap">
            <div
              className="presenter-progress-fill"
              style={{ width: `${Math.round(overallProgress * 100)}%` }}
            />
          </div>

          <div className="presenter-shortcuts-hint">
            <strong className={isPaused ? 'text-yellow' : ''}>
              {isPaused ? '⏸ PAUSED' : '▶ PLAYING'}
            </strong>
            <span> · Space: Pause · ← / →: Step · F: Fullscreen · Esc: Exit</span>
          </div>

          <button
            type="button"
            onClick={onExitPresenter}
            className="presenter-exit-btn"
            title="Exit Presenter Mode (Esc)"
          >
            [Esc]
          </button>
        </div>
      )}

      {/* Persistent Live HUD */}
      <SceneHUD
        currentScene={currentScene}
        report={data.report}
        onSkipAnimation={handleSkipAnimation}
        onOpenUpload={onOpenUpload}
        showSkip={mode !== 'presenter'}
      />

      {/* Persistent Left-Hand Live Index List (Scenes 1-4) */}
      <LiveIndexList
        topics={data.report.topics.items}
        activeTopicIndex={activeTopicIndex}
        visible={currentScene >= 1 && currentScene <= 4}
      />

      {/* Main Container: in timeline mode it's full viewport fixed; in scroll mode it has 1400vh track */}
      <div className={mode === 'scroll' ? 'orchestrator-track' : 'timeline-container'} ref={trackRef}>
        <div className="orchestrator-viewport" ref={viewportRef}>
          {/* Scene 0: Hero (Only in scroll landing mode) */}
          {currentScene === 0 && (
            <HeroScene
              progress={sceneProgress}
              onExplore={handleScrollToNext}
              onOpenUpload={onOpenUpload}
            />
          )}

          {/* Scene 1: (Read) 1.0 */}
          {currentScene === 1 && (
            <ReadScene
              progress={sceneProgress}
              parsedA={data.parsed.a}
              parsedB={data.parsed.b}
            />
          )}

          {/* Scene 2: (Split) 2.0 */}
          {currentScene === 2 && (
            <SplitScene progress={sceneProgress} report={data.report} />
          )}

          {/* Scene 3: (Embed) 3.0 */}
          {currentScene === 3 && (
            <EmbedScene progress={sceneProgress} viz={data.viz} />
          )}

          {/* Scene 4: (Match) 4.0 */}
          {currentScene === 4 && (
            <MatchScene
              progress={sceneProgress}
              viz={data.viz}
              onActiveLinkChange={(idx) => {
                if (idx !== null && data.viz.links[idx]) {
                  const ptAId = data.viz.links[idx].a;
                  const pt = data.viz.points.find((p) => p.id === ptAId);
                  if (pt) {
                    const topicIdx = data.report.topics.items.findIndex(
                      (item) => item.topic === pt.text
                    );
                    setActiveTopicIndex(topicIdx !== -1 ? topicIdx : null);
                  }
                } else {
                  setActiveTopicIndex(null);
                }
              }}
            />
          )}

          {/* Scene 5: (Verdict) 5.0 */}
          {currentScene === 5 && (
            <VerdictScene
              progress={sceneProgress}
              report={data.report}
              viz={data.viz}
              onExploreDashboard={handleSkipAnimation}
            />
          )}
        </div>
      </div>
    </div>
  );
};
